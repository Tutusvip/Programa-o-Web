class CalculadoraSalario {
    constructor() {
        this.funcionarios = [];
    }

    addFuncionario(salarioBruto, desconto, beneficio) {
        const salarioLiquido = salarioBruto - desconto + beneficio;
        this.funcionarios.push({ salarioBruto, desconto, beneficio, salarioLiquido });
        this.atualizarInformacoes();
        this.atualizarLista();
    }

    getMaxSalario() {
        if (this.funcionarios.length === 0) return 0;
        return Math.max(...this.funcionarios.map(funcionario => funcionario.salarioLiquido));
    }

    getTotalDescontos() {
        return this.funcionarios.reduce((total, current) => total + current.desconto, 0);
    }

    atualizarInformacoes() {
        const maxSal1 = document.getElementById('maior-salario');
        const totalDesc1 = document.getElementById('total-descontos');
        maxSal1.innerText = `Maior Salário: R$${this.getMaxSalario().toFixed(2)}`;
        totalDesc1.innerText = `Soma dos Descontos: R$${this.getTotalDescontos().toFixed(2)}`;
    }

    atualizarLista() {
        const listElement = document.getElementById('lista-salarios');
        listElement.innerHTML = '';
        this.funcionarios.forEach(funcionario => {
            const item = document.createElement('li');
            item.innerText = `Salário Líquido: R$${funcionario.salarioLiquido.toFixed(2)}`;
            listElement.appendChild(item);
        });
    }
}

document.addEventListener('DOMContentLoaded', () => {
    const calculator = new CalculadoraSalario();
    const form = document.getElementById('formFuncionario');

    form.addEventListener('submit', (e) => {
        e.preventDefault();

        const salarioBruto = parseFloat(document.getElementById('gross-salary').value);
        const desconto = parseFloat(document.getElementById('desconto').value);
        const beneficio = parseFloat(document.getElementById('beneficio').value);

        calculator.addFuncionario(salarioBruto, desconto, beneficio);

        form.reset();
    });
});
